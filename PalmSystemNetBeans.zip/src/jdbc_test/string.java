package jdbc_test;

class string {
    
}
